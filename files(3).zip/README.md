# Portfolio

A modern, minimal portfolio built with vanilla HTML, CSS, and JavaScript.

## Files

- `index.html` — Home page with about, tools, and studio teaser
- `agency.html` — Full studio/agency page with services and process
- `ayce-calculator.html` — All-you-can-eat restaurant calculator
- `coming-soon.html` — Placeholder for next tool
- `styles.css` — Shared design system and theme
- `app.js` — Shared utilities (theme toggle, scroll reveals, nav state)

## Deploy to Vercel

1. Push this repo to GitHub
2. Import to Vercel (vercel.com)
3. Done — auto-deployed to `your-project.vercel.app`

## Local Development

Open any `.html` file in a browser. No build step needed.

```bash
# Simple HTTP server (Python 3)
python -m http.server 8000

# Or Node
npx http-server
```

Then visit `http://localhost:8000`

## Customization

- Edit placeholders like `[YOUR NAME]`, `[AGENCY NAME]`, `you@example.com`
- Change colors in `styles.css` by editing CSS variables under `:root`
- Modify content directly in HTML files

## Theme

- **Light mode**: Soft off-white background with emerald grid
- **Dark mode**: Charcoal background with rich green grid
- Toggle in top-right corner

---

Built with ♥
